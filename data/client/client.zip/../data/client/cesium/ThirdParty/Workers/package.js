module.exports={type:"commonjs"};
