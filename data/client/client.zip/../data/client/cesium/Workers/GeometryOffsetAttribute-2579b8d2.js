define(["exports"],(function(e){"use strict";var t=Object.freeze({NONE:0,TOP:1,ALL:2});e.GeometryOffsetAttribute=t}));
